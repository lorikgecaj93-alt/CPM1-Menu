package com.example.cpmprototype

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.Switch
import android.widget.EditText

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 11, 18)
    private val panel = Color.rgb(24, 24, 38)
    private val purple = Color.rgb(139, 92, 246)
    private val white = Color.rgb(245, 245, 250)
    private val muted = Color.rgb(164, 164, 185)
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private var selectedTab = "Cars"
    private val demoCars = listOf(
        "BMW M3 E46", "BMW M5 E60", "Mercedes-Benz G63 AMG",
        "Audi R8", "Nissan Skyline R34", "Nissan GT-R R35",
        "Toyota Supra MK4", "Mazda RX-7", "Honda NSX",
        "Lamborghini Aventador", "Bugatti Chiron", "Porsche 911 GT3",
        "Ford Mustang", "Dodge Viper", "Jeep Wrangler",
        "Toyota Land Cruiser", "McLaren P1", "Koenigsegg Jesko"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
        showTab("Cars")
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(14), dp(16), dp(10))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, dp(14))
        }
        header.addView(text("CPM 1  •  MENU PROTOTYPE", 12, purple, true))
        header.addView(text("Garage Control", 28, white, true).apply {
            setPadding(0, dp(5), 0, dp(3))
        })
        header.addView(text("Standalone demo — does not connect to the game", 12, muted, false))
        root.addView(header)

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(panel, 16)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        listOf("Cars", "Money", "Speed").forEach { tab ->
            val b = Button(this).apply {
                text = tab
                isAllCaps = false
                textSize = 13f
                setTextColor(white)
                background = rounded(if (tab == selectedTab) purple else panel, 12)
                setOnClickListener {
                    selectedTab = tab
                    buildScreen()
                    showTab(tab)
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                setMargins(dp(3), 0, dp(3), 0)
            })
        }
        root.addView(nav)

        status = text("DEMO MODE • Game values are unchanged", 11, muted, false).apply {
            setPadding(dp(4), dp(10), dp(4), dp(8))
        }
        root.addView(status)

        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        root.addView(text("Prototype v1.0  •  Local-only controls", 10, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(2))
        })
        setContentView(root)
    }

    private fun showTab(tab: String) {
        content.removeAllViews()
        when (tab) {
            "Cars" -> showCars()
            "Money" -> showMoney()
            "Speed" -> showSpeed()
        }
    }

    private fun showCars() {
        content.addView(sectionTitle("Car catalogue", "Sample roster • search by name"))
        val search = EditText(this).apply {
            hint = "Search cars..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 14f
            setSingleLine(true)
            background = rounded(panel, 12)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        content.addView(search, matchWrap().apply { bottomMargin = dp(12) })
        val listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listBox)
        fun render(query: String) {
            listBox.removeAllViews()
            val results = demoCars.filter { it.contains(query, ignoreCase = true) }
            if (results.isEmpty()) {
                listBox.addView(text("No matching cars in this sample list.", 14, muted, false).apply {
                    setPadding(dp(4), dp(12), 0, dp(12))
                })
            }
            results.forEachIndexed { index, car ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    background = rounded(panel, 14)
                    setPadding(dp(12), dp(10), dp(10), dp(10))
                }
                val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                info.addView(text(car, 14, white, true))
                info.addView(text("Vehicle entry ${index + 1}", 11, muted, false))
                row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                val button = Button(this).apply {
                    text = "Select"
                    isAllCaps = false
                    textSize = 12f
                    setTextColor(white)
                    background = rounded(purple, 10)
                    setOnClickListener {
                        status.text = "Selected locally: $car • no game changes"
                        Toast.makeText(this@MainActivity, "$car selected in demo", Toast.LENGTH_SHORT).show()
                    }
                }
                row.addView(button)
                listBox.addView(row, matchWrap().apply { bottomMargin = dp(8) })
            }
        }
        render("")
        search.addTextChangedListener(SimpleTextWatcher { render(it) })
        content.addView(note("Selecting a car only changes the prototype's local selection. It does not unlock or spawn a vehicle in CPM 1."))
    }

    private fun showMoney() {
        content.addView(sectionTitle("Money controls", "Mock settings only"))
        content.addView(note("These switches are visual demo controls. They do not add cash or gold to your game account."))
        demoSwitch("Infinite money (demo)") { enabled ->
            status.text = "Demo setting: infinite money ${if (enabled) "ON" else "OFF"} • game unchanged"
        }
        demoSwitch("Infinite gold (demo)") { enabled ->
            status.text = "Demo setting: infinite gold ${if (enabled) "ON" else "OFF"} • game unchanged"
        }
        val card = card()
        card.addView(text("Preview balance", 13, muted, false))
        card.addView(text("$ 999,999,999", 25, white, true).apply {
            setPadding(0, dp(6), 0, dp(4))
        })
        card.addView(text("Display example only — not your real balance", 11, muted, false))
        content.addView(card, matchWrap())
    }

    private fun showSpeed() {
        content.addView(sectionTitle("Speed controls", "Local UI preview"))
        content.addView(note("The slider below only updates this screen. It does not change vehicle physics or speed in CPM 1."))
        val card = card()
        val value = text("Demo speed: 100%", 20, white, true)
        card.addView(value)
        val seek = SeekBar(this).apply {
            max = 300
            progress = 100
            progressTintList = android.content.res.ColorStateList.valueOf(purple)
            thumbTintList = android.content.res.ColorStateList.valueOf(purple)
        }
        card.addView(seek, matchWrap())
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val speed = progress.coerceAtLeast(1)
                value.text = "Demo speed: $speed%"
                status.text = "Speed preview: $speed% • game unchanged"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        content.addView(card, matchWrap())
        demoSwitch("Speed boost enabled (demo)") { enabled ->
            status.text = "Demo speed boost ${if (enabled) "ON" else "OFF"} • game unchanged"
        }
    }

    private fun demoSwitch(label: String, changed: (Boolean) -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(panel, 14)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        row.addView(text(label, 14, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply {
            setOnCheckedChangeListener { _, checked -> changed(checked) }
        }
        row.addView(sw)
        content.addView(row, matchWrap().apply { bottomMargin = dp(8) })
    }

    private fun sectionTitle(title: String, subtitle: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(2), dp(12), dp(2), dp(12))
        }
        box.addView(text(title, 20, white, true))
        box.addView(text(subtitle, 12, muted, false).apply { setPadding(0, dp(3), 0, 0) })
        return box
    }

    private fun note(message: String): View {
        return text(message, 12, muted, false).apply {
            background = rounded(panel, 12)
            setPadding(dp(13), dp(12), dp(13), dp(12))
            layoutParams = matchWrap().apply { bottomMargin = dp(12) }
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(panel, 16)
        setPadding(dp(14), dp(14), dp(14), dp(14))
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
