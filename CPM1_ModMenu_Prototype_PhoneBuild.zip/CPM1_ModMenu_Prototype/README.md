# CPM 1 Menu Prototype (Android)

A standalone Android Studio project for a mod-menu-style *visual prototype* with:
- Cars tab: searchable sample vehicle list and local selection
- Money tab: mock money/gold toggles and example balance
- Speed tab: demo slider and toggle

## Important limitation
This is a standalone prototype. It does **not** attach to, modify, or read Car Parking Multiplayer 1. It cannot unlock cars, alter game currency, change vehicle speed, or sync changes to multiplayer. The controls update only this app's UI.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`CPM1_ModMenuPrototype`) in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. When the build completes, use the notification's **Locate** link. The debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

Requires Android SDK 35 and JDK 17 as configured by a current Android Studio installation. If Android Studio suggests a compatible Gradle/Android plugin update, accept its recommended update.

## Project structure
- `app/src/main/java/com/example/cpmprototype/MainActivity.kt` — UI and demo controls
- `app/src/main/java/com/example/cpmprototype/SimpleTextWatcher.kt` — car search input listener
- `app/src/main/AndroidManifest.xml` — app entry point

## Build from your phone with GitHub Actions
This project includes `.github/workflows/build-apk.yml`. Upload the extracted project files to a GitHub repository, open the repository's **Actions** tab, select **Build Android APK**, and tap **Run workflow**. When the run finishes, download the `CPM1-Menu-Prototype-APK` artifact. GitHub may require you to sign in and enable Actions for the repository.
